# ZX_FDD_Emulator
ZX-Spectrum Floppy Disk Emulator for BETA DISK INTERFACE on Arduino

It uses TRD images from SD card as a source data which emulates floppy diskettes.

RUSSIAN

Эмулятор дисковода для ZX-Spectrum, использует образы TRD с SD карты для эмуляции дискет.

PCB example https://github.com/andykarpov/zx-fdd-emulator-pcb

<strong>DONATE:</strong><br>
Yandex: 41001139627896<br>
WebMoney: R594328774666, Z793124813071<br>
PayPal: http://www.avray.ru at the bottom of the page use donation button